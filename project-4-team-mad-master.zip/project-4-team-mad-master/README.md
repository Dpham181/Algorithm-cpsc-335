# project-4
Project 4: String Matching with Dynamic Programming – Part 2

Group members:

Anthony Le | anthonyle63@csu.fullerton.edu

Danh Pham | dpham181@csu.fullerton.com

Matthew McCauley | mccauley@csu.fullerton.edu

Implement the Local String Alignment algorithm. This is a dynamic programming  algorithm that is an extension of the one you wrote in project 3, but uses penalties and performs a local alignment instead of a global alignment.

The local string matching problem is another version of the string matching problem that we investigated in Project 3. However, the local alignment seeks to find the best match for a string within another string, allowing deletions at the beginning and the end to not affect the score. 
