# Project 1: empirical analysis

  Implement and analyze three algorithms. For each algorithm, analyze it mathematically to derive a big-O complexity class; implement the algorithm in C++; analyze the algorithm empirically, by running it for various input sizes and plotting the timing data; and conclude whether the two analyses agree with each other.

Group members:

Anthony Le anthonyle63@csu.fullerton.edu

Danh Pham danhpham312@csu.fullerton.edu

Matthew McCauley mmccauley@csu.fullerton.edu
