///////////////////////////////////////////////////////////////////////////////
// maxprotein_main.cc
//
// Compile with g++ -std=c++11 maxprotein_main.cc -o experiment
//
// Run with ./experiment
///////////////////////////////////////////////////////////////////////////////

#include <iostream>
#include "maxprotein.hh"
#include "timer.hh"

using namespace std;

int main() {
	int min_kcal = 0;
	int max_kcal = 2000;
	int total_kcal = 5000;
	int n;
	
	cout << "Please input the size for filtered foods (no more than 25): \n";
	cin >> n;
	if (n >= 25) {
		n = 25;
	}

	auto source = load_usda_abbrev("ABBREV.txt");
	auto filtered_foods = filter_food_vector(*source, min_kcal, max_kcal, n);

	Timer timer;

	auto output = greedy_max_protein(*filtered_foods, total_kcal);
	double elapsed = timer.elapsed();

	cout << "greedy_max_protein, " << "n = " << n
	<< ", elapsed time = " << elapsed << " seconds " << endl;

	auto output2 = exhaustive_max_protein(*filtered_foods, total_kcal);
	double elapsed2 = timer.elapsed();

	cout << "exhaustive_max_protein, " << "n = " << n
	<< ", elapsed time = " << elapsed2 << " seconds " << endl;
	
	// To compare how close the algorithms are to each other
	int sum = 0;
	for (auto &x : *output){
		sum += x->kcal();
	}
	cout << "sum = " << sum << endl;

	return 0;
}
